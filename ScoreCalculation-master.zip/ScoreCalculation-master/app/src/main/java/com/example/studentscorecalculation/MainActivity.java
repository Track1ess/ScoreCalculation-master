package com.example.studentscorecalculation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textView1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText editText1 = findViewById(R.id.EditText1);
        final EditText editText2 = findViewById(R.id.EditText2);
        Button button1 = findViewById(R.id.Button1);
        Button button2 = findViewById(R.id.Button2);
        textView1 = findViewById(R.id.TextView4);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText1.setText(""); // 用户输入的科目数设为空
                editText2.setText(""); // 用户期望的分数设为空
                textView1.setText(""); // 用户最终的加权成绩设为空
            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = editText1.getText().toString(); // 获取用户输入的科目数
                Intent intent = new Intent(MainActivity.this, YemianActivity.class);
                intent.putExtra("first", number);
                startActivityForResult(intent, 1);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK){
            Uri uriData = data.getData();
            textView1.setText(uriData.toString());
        }
    }
}
