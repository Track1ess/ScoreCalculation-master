package com.example.studentscorecalculation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class YemianActivity extends AppCompatActivity {
    double markSum = 0;
    double finalScore = 0;
    String number1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yemian);

        EditText editText11 = findViewById(R.id.EditText12);
        EditText editText21 = findViewById(R.id.EditText22);
        EditText editText31 = findViewById(R.id.EditText32);
        EditText editText41 = findViewById(R.id.EditText42);
        EditText editText51 = findViewById(R.id.EditText52);
        EditText editText61 = findViewById(R.id.EditText62);
        EditText editText71 = findViewById(R.id.EditText72);
        EditText editText81 = findViewById(R.id.EditText82);
        EditText editText91 = findViewById(R.id.EditText92);
        EditText editText101 = findViewById(R.id.EditText102);
        EditText editText12 = findViewById(R.id.EditText13);
        EditText editText22 = findViewById(R.id.EditText23);
        EditText editText32 = findViewById(R.id.EditText33);
        EditText editText42 = findViewById(R.id.EditText43);
        EditText editText52 = findViewById(R.id.EditText53);
        EditText editText62 = findViewById(R.id.EditText63);
        EditText editText72 = findViewById(R.id.EditText73);
        EditText editText82 = findViewById(R.id.EditText83);
        EditText editText92 = findViewById(R.id.EditText93);
        EditText editText102 = findViewById(R.id.EditText103);
        EditText editText13 = findViewById(R.id.EditText11);
        EditText editText23 = findViewById(R.id.EditText21);
        EditText editText33 = findViewById(R.id.EditText31);
        EditText editText43 = findViewById(R.id.EditText41);
        EditText editText53 = findViewById(R.id.EditText51);
        EditText editText63 = findViewById(R.id.EditText61);
        EditText editText73 = findViewById(R.id.EditText71);
        EditText editText83 = findViewById(R.id.EditText81);
        EditText editText93 = findViewById(R.id.EditText91);
        EditText editText103 = findViewById(R.id.EditText101);


        Button button1 = findViewById(R.id.Button3);
        Button button2 = findViewById(R.id.Button4);
        Button button3 = findViewById(R.id.Button5);

        final EditText[] subject = {editText13, editText23, editText33, editText43, editText53, editText63, editText73, editText83, editText93, editText103};
        final EditText[] score1 = {editText11, editText21, editText31, editText41, editText51, editText61, editText71, editText81, editText91, editText101};
        final EditText[] score2 = {editText12, editText22, editText32, editText42, editText52, editText62, editText72, editText82, editText92, editText102};

        number1 = getIntent().getStringExtra("first"); // 获取用户输入的科目数
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer number = Integer.parseInt(number1); // 将科目数转化为整数
                try{
                    for(int i = 0; i < number; i++){
                        markSum += Double.parseDouble(score2[i].getText().toString()); // 计算总共的学分
                    }
                    for(int j = 0; j < number; j++){
                        finalScore += Double.parseDouble(score1[j].getText().toString()) * (Double.parseDouble(score2[j].getText().toString()) / markSum);
                    } // 计算最终的加权成绩
                    finalScore = (double) Math.round(finalScore * 100) / 100; // 保留两位小数
                    Toast toast = Toast.makeText(YemianActivity.this, "您的加权成绩为：" + String.valueOf(finalScore), Toast.LENGTH_SHORT);
                    toast.show(); // 广播加权成绩
                    Uri data = Uri.parse(String.valueOf(finalScore));
                    Intent result = new Intent(null, data); // 准备传输给主页面加权成绩
                    setResult(RESULT_OK, result);
                    finish();
                }catch (NumberFormatException ie){
                    Toast msg1 = Toast.makeText(YemianActivity.this, "科目不足或输入有误，请重新输入", Toast.LENGTH_SHORT);  // 处理异常
                    msg1.show();
                    for (int i = 0; i < 10; i++){
                        subject[i].setText("");
                        score1[i].setText("");
                        score2[i].setText("");
                    }
                }
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < 10; i++){
                    subject[i].setText(""); // 清空科目输入
                    score1[i].setText(""); // 清空成绩输入
                    score2[i].setText(""); // 清空学分输入
                }
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(YemianActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
